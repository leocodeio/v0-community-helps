import { ComponentShowcase } from "@/components/ui-library/showcase"

export default function UILibraryPage() {
  return (
    <main className="py-12">
      <ComponentShowcase />
    </main>
  )
}
