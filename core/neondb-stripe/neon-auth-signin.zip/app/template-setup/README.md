This directory contains temporary code used for setting up the template

It is only used by the homepage `/app/page.tsx`

Once all of your integrations are correctly configured, you can delete this directory and turn page.tsx
