export const systemPrompt = () => {
  return `You are a helpful AI assistant. Provide clear, concise, and accurate responses to user queries.`
}
